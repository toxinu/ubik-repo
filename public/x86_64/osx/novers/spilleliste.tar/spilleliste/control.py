# coding: utf-8
import os
import sys

from ubik_toolbelt.logger import stream_logger
from ubik_toolbelt.control import Control

from ubik.core import conf

from ubik_toolbelt.contrib import which

class Package(Control):
    def __init__(self):
        Control.__init__(self)
        self.name = 'spilleliste'
        self.version = '0.1.0'
        self.release = '0'
        self.requires = []
        self.arch = ''
        self.dist = ''
        self.vers = ''
        self.description = 'Spilleliste read your iTunes playlist and generate for you a simple but beautiful html page to share with your friends with all the Spotify links (Youtube fallback) you want.'

        self.cur_dir = os.getcwd()
        self.src_dir = os.path.join(os.getcwd(), 'source')
        self.pkg_dir = os.path.join(os.getcwd(), 'build')

    def build(self):
        stream_logger.info('Building...')
        os.chdir(self.src_dir)

        os.makedirs('bin')
        os.chdir('bin')
        os.system('wget --no-check-certificate https://raw.github.com/Socketubs/Spilleliste/master/spilleliste -O spilleliste')
        os.system('chmod +x spilleliste')

    def package(self):
        stream_logger.info('Packaging...')
        os.system('cp -rp %s/* %s' % (self.src_dir, self.pkg_dir))

    def pre_install(self):
        pass

    def post_install(self):
        pass

    def pre_upgrade(self):
        pass

    def post_upgrade(self):
        pass

    def pre_remove(self):
        pass

    def post_remove(self):
        pass
