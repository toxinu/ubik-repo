#!/usr/bin/env python
# -*- coding: utf-8 -*-

__title__ = 'pyhn'
__version__ = '0.1.8'
__author__ = 'Geoffrey Lehée'
__license__ = 'AGPL3'
__copyright__ = 'Copyright 2012 Geoffrey Lehée'
